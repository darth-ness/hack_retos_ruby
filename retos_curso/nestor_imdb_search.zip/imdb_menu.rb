require_relative './imdb_collector'

class ImdbMenu

  def show_menu
    system('clear')
    puts "**** Buscador de películas en IMDB ****"
    puts
    puts 'MENU'
    puts
    puts '1) Buscar por título'
    puts '2) Buscar por año <<---# NO Implementada aún #--->>' 
    puts
    puts '0) Para salir'
    puts
    print "Por favor ingrese una opción: "
    answer = gets.chomp.to_i

    unless answer == 0
      if answer == 1
        do_title_search
      elsif answer == 2
        show_year_search
      else
        puts "Por favor ingrese una opción válida..."
        show_menu
      end
    end

  end

  private

  def do_title_search
    system('clear')
    puts '**** Buscar por Título ****'
    puts
    print 'Por favor ingrese el título: '
    answer = gets.chomp

    request = ImdbCollector.new.get answer
    print_title_search request
  end

  def print_title_search request
    request.each_with_index do |item, i|
      puts "#{i+1}.) TÍTULO: #{item['title']},"
      puts "AÑO: #{item['year']},"
      puts "DESCRIPCION: #{item['plot']}"
      puts
    end

    print "Elija el número de la película de su gusto: "
    selection = gets.chomp.to_i

    if selection < 1 || selection > request.length
      print_title_search request
    else
      puts
      puts "TÍTULO: #{request[selection-1]['title']},"
      puts "DESCRIPCIÓN: #{request[selection-1]['plot']}"
      puts "AÑO: #{request[selection-1]['year']},"
      puts "GÉNERO: #{request[selection-1]['genre']},"
      puts "ACTORES: #{request[selection-1]['actors']},"
      puts
    end

    puts "Presione ENTER para regresar..."
    gets
    show_menu
  end
end

ImdbMenu.new.show_menu
