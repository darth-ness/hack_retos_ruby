require 'rest-client'
require 'json'

class ImdbCollector

  def initialize
    @endpoint = 'http://www.omdbapi.com/?'
    @title = 'Title'
    @year = 'Year'
    @ID = 'imdbID'
    # @search = search
  end

  def get query
    raw_list = grab_titles(query)['Search']
    movies = []

    raw_list.each_with_index do |item, i|
      movies[i] = {}
      movies[i]['title'] = item[@title]
      movies[i]['year'] = item[@year]
      movies[i]['ID'] =  item[@ID]
      cross = grab_plot item[@ID]
      movies[i]['plot'] = cross['Plot']
      movies[i]['genre'] = cross['Genre']
      movies[i]['actors'] = cross['Actors']
    end

    movies
  end

  private

  def grab_titles search
    response = RestClient.get @endpoint, {:params => {:s => search}}

    JSON.parse(response.body)
  end

  def grab_plot search
    response = RestClient.get @endpoint, {:params => {:i => search}}

    JSON.parse(response.body)
  end
end
