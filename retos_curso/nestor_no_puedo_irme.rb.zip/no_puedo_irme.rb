

class Plain
    def initialize(pilot, people_flying, from, destiny)
        @pilot = pilot
        @people_flying = people_flying
        @from = from
        @destination = destiny
    end
end

x = Plain.new('Juan', 234, 'Italy', 'Venezuela')
