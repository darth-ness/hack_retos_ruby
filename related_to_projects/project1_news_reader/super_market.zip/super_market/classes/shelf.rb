class Shelf
  attr_accessor :products

  def initialize products
    @products = products
  end
end
