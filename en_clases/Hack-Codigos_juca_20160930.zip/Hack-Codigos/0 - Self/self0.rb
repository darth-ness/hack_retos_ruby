class S  
  def m
  	system("clear")
    puts "Clase #{self.class}, metodo m:"
    puts self # <S:0x2835908> 
    puts class.m
  end  
end  
s = S.new  
s.m