SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

CREATE SCHEMA IF NOT EXISTS `reto1hack` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
USE `reto1hack` ;

-- -----------------------------------------------------
-- Table `reto1hack`.`Persons`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `reto1hack`.`Persons` ;

CREATE TABLE IF NOT EXISTS `reto1hack`.`Persons` (
  `id` INT NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `password` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `email_UNIQUE` (`email` ASC))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `reto1hack`.`Profiles`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `reto1hack`.`Profiles` ;

CREATE TABLE IF NOT EXISTS `reto1hack`.`Profiles` (
  `id` INT NOT NULL,
  `id_person` INT NOT NULL,
  `dni` VARCHAR(45) NOT NULL,
  `name` VARCHAR(45) NULL,
  `lastname` VARCHAR(45) NULL,
  `birthday` DATE NULL,
  `gender` ENUM('masculino', 'femenino', 'otro') NOT NULL,
  `car` TINYINT(1) NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  INDEX `fk_Profiles_Persons1_idx` (`id_person` ASC),
  CONSTRAINT `fk_Profiles_Persons1`
    FOREIGN KEY (`id_person`)
    REFERENCES `reto1hack`.`Persons` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `reto1hack`.`Phones`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `reto1hack`.`Phones` ;

CREATE TABLE IF NOT EXISTS `reto1hack`.`Phones` (
  `id` INT NOT NULL,
  `id_profile` INT NOT NULL,
  `phone_number` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`id`, `id_profile`),
  CONSTRAINT `fk_Phones_1`
    FOREIGN KEY (`id_profile`)
    REFERENCES `reto1hack`.`Profiles` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `reto1hack`.`Mentors`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `reto1hack`.`Mentors` ;

CREATE TABLE IF NOT EXISTS `reto1hack`.`Mentors` (
  `id` INT NOT NULL,
  `id_profile` INT NOT NULL,
  `entry_date` DATE NULL,
  `contract_type` ENUM('resident', 'guest') NOT NULL DEFAULT 'guest',
  PRIMARY KEY (`id`, `id_profile`),
  INDEX `fk_Mentors_Profiles1_idx` (`id_profile` ASC),
  CONSTRAINT `fk_Mentors_Profiles1`
    FOREIGN KEY (`id_profile`)
    REFERENCES `reto1hack`.`Profiles` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `reto1hack`.`Students`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `reto1hack`.`Students` ;

CREATE TABLE IF NOT EXISTS `reto1hack`.`Students` (
  `id` INT NOT NULL,
  `id_profile` INT NOT NULL,
  `laptop` TINYINT(1) NOT NULL DEFAULT 1,
  `job_market` TINYINT(1) NOT NULL DEFAULT 1,
  `reference` INT NULL,
  PRIMARY KEY (`id`, `id_profile`),
  INDEX `fk_Students_Profiles1_idx` (`id_profile` ASC),
  INDEX `fk_Students_Profiles2_idx` (`reference` ASC),
  CONSTRAINT `fk_Students_Profiles1`
    FOREIGN KEY (`id_profile`)
    REFERENCES `reto1hack`.`Profiles` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Students_Profiles2`
    FOREIGN KEY (`reference`)
    REFERENCES `reto1hack`.`Profiles` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `reto1hack`.`Courses`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `reto1hack`.`Courses` ;

CREATE TABLE IF NOT EXISTS `reto1hack`.`Courses` (
  `id` INT NOT NULL,
  `name` VARCHAR(45) NOT NULL,
  `duration` VARCHAR(45) NOT NULL,
  `description` TEXT NULL,
  `student_profile` TEXT NULL,
  `graduate_profile` TEXT NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `reto1hack`.`Cohorts`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `reto1hack`.`Cohorts` ;

CREATE TABLE IF NOT EXISTS `reto1hack`.`Cohorts` (
  `id` INT NOT NULL,
  `id_course` INT NOT NULL,
  `start_date` DATE NULL,
  `finish_date` DATE NULL,
  `location` TEXT NULL,
  PRIMARY KEY (`id`, `id_course`),
  INDEX `fk_Cohorts_Courses1_idx` (`id_course` ASC),
  CONSTRAINT `fk_Cohorts_Courses1`
    FOREIGN KEY (`id_course`)
    REFERENCES `reto1hack`.`Courses` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `reto1hack`.`Students_has_Cohorts`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `reto1hack`.`Students_has_Cohorts` ;

CREATE TABLE IF NOT EXISTS `reto1hack`.`Students_has_Cohorts` (
  `Students_id` INT NOT NULL,
  `Students_id_profile` INT NOT NULL,
  `Cohorts_id` INT NOT NULL,
  `Cohorts_id_course` INT NOT NULL,
  PRIMARY KEY (`Students_id`, `Students_id_profile`, `Cohorts_id`, `Cohorts_id_course`),
  INDEX `fk_Students_has_Cohorts_Cohorts1_idx` (`Cohorts_id` ASC, `Cohorts_id_course` ASC),
  INDEX `fk_Students_has_Cohorts_Students1_idx` (`Students_id` ASC, `Students_id_profile` ASC),
  CONSTRAINT `fk_Students_has_Cohorts_Students1`
    FOREIGN KEY (`Students_id`)
    REFERENCES `reto1hack`.`Students` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Students_has_Cohorts_Cohorts1`
    FOREIGN KEY (`Cohorts_id` , `Cohorts_id_course`)
    REFERENCES `reto1hack`.`Cohorts` (`id` , `id_course`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `reto1hack`.`Mentors_has_Cohorts`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `reto1hack`.`Mentors_has_Cohorts` ;

CREATE TABLE IF NOT EXISTS `reto1hack`.`Mentors_has_Cohorts` (
  `Mentors_id` INT NOT NULL,
  `Mentors_id_profile` INT NOT NULL,
  `Cohorts_id` INT NOT NULL,
  `Cohorts_id_course` INT NOT NULL,
  PRIMARY KEY (`Mentors_id`, `Mentors_id_profile`, `Cohorts_id`, `Cohorts_id_course`),
  INDEX `fk_Mentors_has_Cohorts_Cohorts1_idx` (`Cohorts_id` ASC, `Cohorts_id_course` ASC),
  INDEX `fk_Mentors_has_Cohorts_Mentors1_idx` (`Mentors_id` ASC, `Mentors_id_profile` ASC),
  CONSTRAINT `fk_Mentors_has_Cohorts_Mentors1`
    FOREIGN KEY (`Mentors_id` , `Mentors_id_profile`)
    REFERENCES `reto1hack`.`Mentors` (`id` , `id_profile`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Mentors_has_Cohorts_Cohorts1`
    FOREIGN KEY (`Cohorts_id` , `Cohorts_id_course`)
    REFERENCES `reto1hack`.`Cohorts` (`id` , `id_course`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;



-- -----------------------------------------------------
-- INSERCIÓN DE REGISTROS
-- -----------------------------------------------------

