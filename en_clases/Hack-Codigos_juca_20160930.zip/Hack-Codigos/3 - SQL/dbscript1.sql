drop table if exists students;
drop table if exists mentors;
drop table if exists phones;
drop table if exists courses;
drop table if exists persons_courses;

create table students(
	id int primary key auto_increment,
	vehicule bool,
	id_persons int not null unique,
	foreign key (id_persons) references persons(id)
);

create table mentors(
	id int auto_increment primary key,
	vehicule bool,
	id_persons int not null unique,
	foreign key (id_persons) references persons(id)
);

insert into persons (name, lastn) values ('Juan', 'Manriquez');
insert into persons (name, lastn) values ('Juan', 'Manriques');
insert into persons (name, lastn) values ('Juanito', 'Manriques');

insert into mentors (id_persons) values (1);
insert into mentors (id_persons) values (2);
insert into mentors (id_persons) values (1);

insert into students (id_persons) values (4);
insert into students (id_persons) values (2);

create table phones(
	id int primary key auto_increment,
	phone varchar(12) not null unique,
	id_persons int,
	foreign key (id_persons) references persons(id)
);

insert into phones (phone, id_persons) values ('43543654', 1);
insert into phones (phone, id_persons) values ('76456', 1);
insert into phones (phone, id_persons) values ('23245234', 2);
insert into phones (phone, id_persons) values ('645635', 2);
insert into phones (phone, id_persons) values ('756756', 2);
insert into phones (phone, id_persons) values ('245234', 4);
insert into phones (phone, id_persons) values ('234567', 4);
insert into phones (phone, id_persons) values ('876543', 5);

create table courses(
	id int primary key auto_increment,
	name varchar(50) not null unique
);

create table persons_courses(
	id_persons int,
	id_courses int,
	foreign key (id_persons) references persons(id),
	foreign key (id_courses) references courses(id)
);

insert into courses (name) values ('HumanToDev');
insert into courses (name) values ('DevToHack');

insert into persons_courses (id_persons, id_courses) values (2, 1);
insert into persons_courses (id_persons, id_courses) values (4, 1);
insert into persons_courses (id_persons, id_courses) values (5, 1);
insert into persons_courses (id_persons, id_courses) values (6, 1);
insert into persons_courses (id_persons, id_courses) values (7, 1);
insert into persons_courses (id_persons, id_courses) values (8, 1);
insert into persons_courses (id_persons, id_courses) values (9, 1);
insert into persons_courses (id_persons, id_courses) values (10, 1);
insert into persons_courses (id_persons, id_courses) values (11, 1);
insert into persons_courses (id_persons, id_courses) values (12, 1);
insert into persons_courses (id_persons, id_courses) values (12, 2);
insert into persons_courses (id_persons, id_courses) values (1, 2);
insert into persons_courses (id_persons, id_courses) values (2, 2);
insert into persons_courses (id_persons, id_courses) values (12, 1);