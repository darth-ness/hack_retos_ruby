create table persons (id int, name varchar(50), lastname varchar(50), dni varchar(10), birth_date date, primary key (id) );

desc persons;

insert into persons (id, name, lastname) values (2, 'Juan', 'Manrique');

alter table persons change id ids;

alter table persons change ids id int auto_increment primary key;

insert into persons (name, lastname) values ('Juan', 'Manrique');

alter table persons change name name varchar(50) not null;
alter table persons modify name varchar(50) not null;

truncate table persons;

update persons set dni='12345678' where name='Juan';
update persons set dni='12345678' where name='Juan' and lastname='manrique';
update persons set dni='000000' where dni='1234567';
update persons set dni='0000001' where id=4;

create table profiles (id int primary key, email text, mobile varchar(12), id_persons int, foreign key(id_persons) references persons(id) on delete cascade on update cascade);

alter table profiles modify id_persons int(11) not null;
alter table profiles modify id int(11) auto_increment;

DELETE FROM persons WHERE dni=NULL;
DELETE FROM persons WHERE dni='';

alter table profiles add constraint u_profile_email unique (email);
alter table profiles modify id_persons int unique;

insert into profiles (email, id_persons) values ('jmanrique@academiahack.com.ve', 2);

delete from persons where id=2;

