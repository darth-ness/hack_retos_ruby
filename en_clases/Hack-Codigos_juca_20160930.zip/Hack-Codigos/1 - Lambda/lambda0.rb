def el_metodo(mi_arg)
	mi_closure = proc do |mi_ar|
		return "Toma esto: #{mi_ar}"
	end

	puts "Wep: " + mi_closure.call(mi_arg)
	return "Machete!"
end

puts el_metodo "Yuca!"