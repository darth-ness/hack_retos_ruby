class Person < ActiveRecord::Base
	has_one :profile
end
