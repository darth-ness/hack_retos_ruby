class Profile < ActiveRecord::Base
  enum gender: {masculino: 0, femenino: 1, otro: 2}
  belongs_to :person
  has_many :phones
end
