class Profile < ActiveRecord::Base
  validates_uniqueness_of :person_id, message: "This profiles has a owner already."
  enum gender: {masculino: 0, femenino: 1, otro: 2}
  belongs_to :person
  has_many :phones
end
