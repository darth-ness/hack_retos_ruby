class PhonesController < ApplicationController
  def index
  end

  def create
  end

  def show
  end

  def update
  end

  def destroy
  end
end
