class PeopleController < ApplicationController
  def index
    render json: Person.all
  end

  def create
  	puts params.inspect
    @person = Person.new
    @person.email = params[:email]
    @person.password = params[:password]
    if @person.save then
    	render json: @person
    else
    	render json: {"error" => @person.errors, "status" => "500"}
    end
  end

  def show
    @pers = Person.find(params[:id])
    render json: {person: @pers, profile: @pers.profile}
  end

  def update
  end

  def destroy
  end
end
