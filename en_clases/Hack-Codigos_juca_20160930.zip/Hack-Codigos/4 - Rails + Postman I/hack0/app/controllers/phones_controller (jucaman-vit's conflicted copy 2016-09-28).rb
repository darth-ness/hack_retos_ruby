class PhonesController < ApplicationController
  def index
    puts params[:position].class
    @pers = Person.find(params[:person_id])
    if params.has_key?(:position) then
      render json: @pers.profile.phones[params[:position].to_i - 1]
    else
      render json: @pers.profile.phones
    end
  end

  def create
    @pers = Person.find(params[:person_id])

    if !params.has_key?(:setting)
      @phon = Phone.new
      @phon.phone_number = params[:phone_number]
      @phon.profile = @pers.profile
      
      if @phon.save
        render json: @phon
      else
        render json: {"errors": @phon.errors, "code": 500}
      end
    elsif params[:setting] == "mass"
=begin
Para guardado de varios telefonos a la vez (en un mismo request, en masa),
la estructura del json con los telefonos debe ser de la forma:
{
  "phones": [
    {
      "phone_number": "333333333"
    },
    {
      "phone_number": "444444444"
    }
  ]
}
=end
      params[:phones].each do |h|
        @pers.profile.phones.push(Phone.new({phone_number: h[:phone_number]}))
      end
      if @pers.save
        render json: @pers.profile.phones
      else
        render json: {"errors": @pers.errors, "code": 500}
      end
    end
  end

  def show
    render json: Person.find(params[:person_id]).profile.phones[params[:id].to_i - 1]
  end

  def update
  end

  def destroy
  end

end

