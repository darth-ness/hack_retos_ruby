class ProfilesController < ApplicationController
  def index
    puts params.inspect
    render json: Profile.all
  end

  def create
    @person = Person.find(params[:person_id])
    
    @prof = Profile.new(profile_params)
    
    @prof.person = @person
    if @prof.save then
      render json: @prof
    else
      render json: {"errors": @prof.errors, "code": 500}
    end
  end

  def show
  end

  def update
  end

  def destroy
  end

  def profile_params
    params.permit(:dni, :name, :lastname, :birthdate, :gender, :car)
    # params.require([:profile]).permit(:dni, :name, :lastname, :birthdate, :gender, :car)
  end
end



  # def index
  #   puts params.inspect
  #   if params.has_key?(:filter) then
  #     if params[:filter] == "categorie" then
  #       render json: Product.all_by_categorie params[:categorie]
  #     elsif params[:filter] == "name" then
  #       render json: Product.all_by_name params[:name]
  #     end
  #   else
  #     render json: Profile.all
  #   end

  # end