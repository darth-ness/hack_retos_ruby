class CreateProfiles < ActiveRecord::Migration
  def change
    create_table :profiles do |t|
      t.string :dni, null: false
      t.string :name, null: false
      t.string :lastname, null: false
      t.date :birthdate, null: false
      t.integer :gender, null: false, default: "masculino"
      t.boolean :car, default: false
      t.references :person, index: true, foreign_key: true, null: false, unique: true

      t.timestamps null: false
    end
  end
end
